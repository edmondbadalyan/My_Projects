﻿
Console.WriteLine("Give me length:");
int length = int.Parse(Console.ReadLine());
Console.WriteLine("Give me heigth:");
int heigth = int.Parse(Console.ReadLine());
Console.WriteLine("Give me width:");
int width = int.Parse(Console.ReadLine());

Random random = new Random();

int[,,] three_dimensions_array = new int[length, heigth, width];
int sum = 0;
int count = 0;
int min = int.MaxValue;
int max = int.MinValue;
for (int i = 0; i < length; i++)
{
    Console.WriteLine($"Layer {i + 1}:");

    for (int j = 0; j < heigth; j++)
    {
        for (int k = 0; k < width; k++)
        {
            three_dimensions_array[i, j, k] = random.Next(-5, 5);
            Console.Write($"{three_dimensions_array[i, j, k],5} ");

            sum += three_dimensions_array[i, j, k];

            count++;

            if (three_dimensions_array[i, j, k] < min)
                min = three_dimensions_array[i, j, k];

            if (three_dimensions_array[i, j, k] > max)
                max = three_dimensions_array[i, j, k];
        }
        Console.WriteLine();
    }
    Console.WriteLine();

}

Console.WriteLine($"Sum of all elements in array: {sum}");

double average = (double)sum / count;
Console.WriteLine($"Average sum: {average}");
Console.WriteLine($"Minimum element of all arays: {min}");
Console.WriteLine($"Maximum element of all arays: {max}");

Console.WriteLine();

Console.WriteLine("Write a words: ");
string input = Console.ReadLine();

string[] words = input.Split(' ');

Array.Reverse(words);

string result = string.Join(" ", words);



Console.WriteLine($"{result}");



